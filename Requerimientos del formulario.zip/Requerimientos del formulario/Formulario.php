<html>
    <head>
        
    </head>
    <body>
        <form action="resultados.php" method="post">
            <h2>Datos del cliente</h2>
            <label for="nombre">Nombre completo:</label>
            <input type="text" id="nombre" name="nombre" required><br><br>
            <label for="correo">Correo electrónico:</label>
            <input type="email" id="correo" name="correo" required><br><br>

            <h2>Destinos turísticos</h2>
            <select id="destinos" name="destinos[]" multiple>
                <option value="Cancún">Cancún</option>
                <option value="Puerto Vallarta">Puerto Vallarta</option>
                <option value="Acapulco">Acapulco</option>
                <option value="Los Cabos">Los Cabos</option>
                <option value="Mazatlán">Mazatlán</option>
                <option value="Huatulco">Huatulco</option>
                <option value="Puerto Escondido">Puerto Escondido</option>
            </select><br><br>

            <h2>Actividades turísticas</h2>
            <label for="act-1">
                <input type="checkbox" value="Buceo" id="act-1" name="actividades[]">
                Buceo
            </label><br><br>
            <label for="act-2">
                <input type="checkbox" value="Paseo en lancha" id="act-2" name="actividades[]">
                Paseo en lancha
            </label><br><br>
            <label for="act-3">
                <input type="checkbox" value="Visita a zonas arqueológicas" id="act-3" name="actividades[]">
                Visita a zonas arqueológicas
            </label><br><br>
            <label for="act-4">
                <input type="checkbox" value="Senderismo" id="act-4" name="actividades[]">
                Senderismo
            </label><br><br>
            <label for="act-5">
                <input type="checkbox" value="Pesca deportiva" id="act-5" name="actividades[]">
                Pesca deportiva
            </label><br><br>
            <label for="act-6">
                <input type="checkbox" value="Recorrido gastronómico" id="act-6" name="actividades[]">
                Recorrido gastronómico
            </label><br><br>
            <label for="act-7">
                <input type="checkbox" value="Visita a museos" id="act-7" name="actividades[]">
                Visita a museos
            </label><br><br>

            <h2>Servicios adicionales</h2>
            <label for="srv-1">
                <input type="checkbox" value="Transporte al aeropuerto" id="srv-1" name="servicios[]">
                Transporte al aeropuerto
            </label><br><br>
            <label for="srv-2">
                <input type="checkbox" value="Desayuno incluido" id="srv-2" name="servicios[]">
                Desayuno incluido
            </label><br><br>
            <label for="srv-3">
                <input type="checkbox" value="Hospedaje de lujo" id="srv-3" name="servicios[]">
                Hospedaje de lujo
            </label><br><br>
            <label for="srv-4">
                <input type="checkbox" value="Seguro de viajero" id="srv-4" name="servicios[]">
                Seguro de viajero
            </label><br><br>
            <label for="srv-5">
                <input type="checkbox" value="Renta de automóvil" id="srv-5" name="servicios[]">
                Renta de automóvil
            </label><br><br>
            <label for="srv-6">
                <input type="checkbox" value="Guía turístico" id="srv-6" name="servicios[]">
                Guía turístico
            </label><br><br>

            <button type="submit" value="Generar paquete">Generar paquete</button>
        </form>
    </body>
</html>  