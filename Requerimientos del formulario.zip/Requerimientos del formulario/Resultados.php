<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $correo = $_POST['correo'] ?? '';
    $destinos = $_POST['destinos'] ?? [];
    $actividades = $_POST['actividades'] ?? [];
    $servicios = $_POST['servicios'] ?? [];

    echo "<h1>Resumen del paquete turístico</h1>";
    echo "<p>Nombre completo: " . $nombre . "</p>";
    echo "<p>Correo electrónico: " . $correo . "</p>";

    echo "<h2>Destinos elegidos:</h2>";
    if (empty($destinos)) {
        echo "<p>No seleccionaste ningún elemento</p>";
    } else {
        echo "<ul>";
        foreach ($destinos as $de) {
            echo "<li>" . $de . "</li>";
        }
        echo "</ul>";
    }
    echo "<p>Total de destinos: " . count($destinos) . "</p>";

    echo "<h2>Actividades elegidas:</h2>";
    if (empty($actividades)) {
        echo "<p>No seleccionaste ningún elemento</p>";
    } else {
        echo "<ul>";
        foreach ($actividades as $ac) {
            echo "<li>" . $ac . "</li>";
        }
        echo "</ul>";
    }
    echo "<p>Total de actividades: " . count($actividades) . "</p>";

    echo "<h2>Servicios adicionales elegidos:</h2>";
    if (empty($servicios)) {
        echo "<p>No seleccionaste ningún elemento</p>";
    } else {
        echo "<ul>";
        foreach ($servicios as $se) {
            echo "<li>" . $se . "</li>";
        }
        echo "</ul>";
    }
    echo "<p>Total de servicios adicionales: " . count($servicios) . "</p>";

    $totalGeneral = count($destinos) + count($actividades) + count($servicios);
    echo "<h2>Total general</h2>";
    echo "<p>Total general de elementos seleccionados: " . $totalGeneral . "</p>";
} else {
    echo "<p>Envía el formulario primero.</p>";
}
?>